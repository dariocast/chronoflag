export const ssr=false;
